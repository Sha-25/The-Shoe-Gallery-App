import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>Welcome To Footish</h2>
        <p>Where you will experience unique high-end shoe fashion.  
           Here you will see the most eccentric shoes ever seen in the world. 
           These masterpieces are truly works of art.

        </p>
 
        <p>Duis a turpis sed lacus dapibus elementum sed eu lectus.</p>
      </div>
    );
  }
}
 
export default Home;